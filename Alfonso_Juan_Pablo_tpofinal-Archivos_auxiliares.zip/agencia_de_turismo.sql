-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-12-2021 a las 23:13:52
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `agencia_de_turismo`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `ID_CLIENTE` int(11) NOT NULL,
  `APELLIDO` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `CELULAR` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `DIRECCION` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `DNI` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `EMAIL` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `FECHA_NAC` date DEFAULT NULL,
  `NACIONALIDAD` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `NOMBRE` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`ID_CLIENTE`, `APELLIDO`, `CELULAR`, `DIRECCION`, `DNI`, `EMAIL`, `FECHA_NAC`, `NACIONALIDAD`, `NOMBRE`) VALUES
(162, '-', '-', '-', '-', '-@a', '2021-12-20', '-', '(Cliente borrado)'),
(163, 'Porta', '2494355791', 'Costa Rica 477', '13244799', 'liana@gmail.com', '1957-10-18', 'Argentina', 'Liana'),
(164, 'Alfonso', '2494567891', 'Costarica 477', '8003051', 'carlos@gmail.com', '1950-02-22', 'Argentino', 'Carlos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente_venta`
--

CREATE TABLE `cliente_venta` (
  `Cliente_ID_CLIENTE` int(11) NOT NULL,
  `listaVentas_NUM_VENTA` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `cliente_venta`
--

INSERT INTO `cliente_venta` (`Cliente_ID_CLIENTE`, `listaVentas_NUM_VENTA`) VALUES
(163, 165),
(163, 169),
(164, 166);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE `empleado` (
  `ID_EMPLEADO` int(11) NOT NULL,
  `APELLIDO` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `CARGO` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `CELULAR` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `DIRECCION` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `DNI` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `EMAIL` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `FECHA_NAC` date DEFAULT NULL,
  `NACIONALIDAD` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `NOMBRE` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `SUELDO` double DEFAULT NULL,
  `UNUSUARIO_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `empleado`
--

INSERT INTO `empleado` (`ID_EMPLEADO`, `APELLIDO`, `CARGO`, `CELULAR`, `DIRECCION`, `DNI`, `EMAIL`, `FECHA_NAC`, `NACIONALIDAD`, `NOMBRE`, `SUELDO`, `UNUSUARIO_ID`) VALUES
(2, 'Pabló', 'Jefe', '2494539993', 'Urquiza 872', '33356567', 'juanpa_fqks@hotmail.com', '1988-01-06', 'Argentino', 'Juan', 384000, 1),
(156, 'Mares', 'Empleado', '1264632213', '9 de Julio 872', '32181160', 'nata@hotmail.com', '2000-02-27', 'Argentina', 'Nata', 90000, 155),
(161, '-', '-', '-', '-', '-', '-@a', '2021-12-01', '-', '(Empleado borrado)', 0, 160);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado_venta`
--

CREATE TABLE `empleado_venta` (
  `Empleado_ID_EMPLEADO` int(11) NOT NULL,
  `listaVentas_NUM_VENTA` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `empleado_venta`
--

INSERT INTO `empleado_venta` (`Empleado_ID_EMPLEADO`, `listaVentas_NUM_VENTA`) VALUES
(2, 165),
(156, 166),
(156, 169);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paquete_turistico`
--

CREATE TABLE `paquete_turistico` (
  `CODIGO` int(11) NOT NULL,
  `COSTO_PAQUETE` double DEFAULT NULL,
  `DISPONIBLE` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `paquete_turistico`
--

INSERT INTO `paquete_turistico` (`CODIGO`, `COSTO_PAQUETE`, `DISPONIBLE`) VALUES
(14, 944100, 1),
(15, 1800, 1),
(16, 5850, 1),
(17, 27900, 1),
(18, 914400, 1),
(19, 10350, 1),
(22, 4050, 1),
(158, 34200, 1),
(168, 927900, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paquete_turistico_servicio`
--

CREATE TABLE `paquete_turistico_servicio` (
  `Paquete_turistico_CODIGO` int(11) NOT NULL,
  `listaServicios_CODIGO` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `paquete_turistico_servicio`
--

INSERT INTO `paquete_turistico_servicio` (`Paquete_turistico_CODIGO`, `listaServicios_CODIGO`) VALUES
(14, 7),
(14, 8),
(14, 9),
(14, 10),
(14, 11),
(14, 12),
(14, 13),
(15, 7),
(15, 8),
(16, 8),
(16, 9),
(17, 9),
(17, 10),
(18, 11),
(18, 12),
(18, 13),
(19, 7),
(19, 13),
(22, 7),
(22, 20),
(158, 10),
(158, 13),
(158, 20),
(168, 10),
(168, 11),
(168, 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paquete_turistico_venta`
--

CREATE TABLE `paquete_turistico_venta` (
  `Paquete_turistico_CODIGO` int(11) NOT NULL,
  `listaVentas_NUM_VENTA` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `paquete_turistico_venta`
--

INSERT INTO `paquete_turistico_venta` (`Paquete_turistico_CODIGO`, `listaVentas_NUM_VENTA`) VALUES
(17, 166);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sequence`
--

CREATE TABLE `sequence` (
  `SEQ_NAME` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `SEQ_COUNT` decimal(38,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `sequence`
--

INSERT INTO `sequence` (`SEQ_NAME`, `SEQ_COUNT`) VALUES
('SEQ_GEN', '200');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio`
--

CREATE TABLE `servicio` (
  `CODIGO` int(11) NOT NULL,
  `COSTO` double DEFAULT NULL,
  `DESCRIPCION` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `DESTINO` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `DISPONIBLE` tinyint(1) DEFAULT 0,
  `FECHA` date DEFAULT NULL,
  `NOMBRE` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `servicio`
--

INSERT INTO `servicio` (`CODIGO`, `COSTO`, `DESCRIPCION`, `DESTINO`, `DISPONIBLE`, `FECHA`, `NOMBRE`) VALUES
(7, 1500, 'Un finde en Mardel', 'Mar del Plata', 1, '2021-12-28', 'Hotel por noche'),
(8, 500, 'Un auto viejo', 'Tandil', 0, '2021-12-27', 'Alquiler de auto'),
(9, 6000, 'Me voy a Neco', 'Necochea', 1, '2022-01-07', 'Pasaje de colectivo'),
(10, 25000, 'Una escapada a Salta', 'Salta', 1, '2022-03-31', 'Pasaje de avion'),
(11, 1000000, 'Un viaje a Howart', 'La casa de Harry Potter', 1, '2022-03-10', 'Pasaje de tren'),
(12, 6000, 'Conociendo la garganta del diablo', 'Iguazú', 1, '2022-01-10', 'Excursion'),
(13, 10000, 'Concierto de Callejeros', 'Azul', 1, '2022-01-15', 'Entrada a evento'),
(20, 3000, 'Para pasear', 'incierto', 1, '2022-02-10', 'Alquiler de auto'),
(21, 70000, 'Unos dias lejos', 'Hollywood', 1, '2022-07-01', 'Pasaje de avion'),
(23, 50000, 'pasear', 'Hawai', 1, '2022-01-04', 'Excursion');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio_paquete_turistico`
--

CREATE TABLE `servicio_paquete_turistico` (
  `Servicio_CODIGO` int(11) NOT NULL,
  `listaPaquetes_CODIGO` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `servicio_paquete_turistico`
--

INSERT INTO `servicio_paquete_turistico` (`Servicio_CODIGO`, `listaPaquetes_CODIGO`) VALUES
(7, 14),
(7, 15),
(7, 19),
(7, 22),
(8, 14),
(8, 15),
(8, 16),
(9, 14),
(9, 16),
(9, 17),
(10, 14),
(10, 17),
(10, 158),
(10, 168),
(11, 14),
(11, 18),
(11, 168),
(12, 14),
(12, 18),
(12, 168),
(13, 14),
(13, 18),
(13, 19),
(13, 158),
(20, 22),
(20, 158);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio_venta`
--

CREATE TABLE `servicio_venta` (
  `Servicio_CODIGO` int(11) NOT NULL,
  `listaVentas_NUM_VENTA` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `servicio_venta`
--

INSERT INTO `servicio_venta` (`Servicio_CODIGO`, `listaVentas_NUM_VENTA`) VALUES
(12, 169),
(13, 165);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `ID` int(11) NOT NULL,
  `CONTRASENIA` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `NOMBREUSUARIO` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`ID`, `CONTRASENIA`, `NOMBREUSUARIO`) VALUES
(1, '1234', '33juanpa33'),
(155, '1234', 'juan'),
(160, '-', '-');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta`
--

CREATE TABLE `venta` (
  `NUM_VENTA` int(11) NOT NULL,
  `FECHA_VENTA` date DEFAULT NULL,
  `MEDIO_PAGO` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `UNCLIENTE_ID_CLIENTE` int(11) DEFAULT NULL,
  `UNEMPLEADO_ID_EMPLEADO` int(11) DEFAULT NULL,
  `UNPAQUETE_CODIGO` int(11) DEFAULT NULL,
  `UNSERVICIO_CODIGO` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `venta`
--

INSERT INTO `venta` (`NUM_VENTA`, `FECHA_VENTA`, `MEDIO_PAGO`, `UNCLIENTE_ID_CLIENTE`, `UNEMPLEADO_ID_EMPLEADO`, `UNPAQUETE_CODIGO`, `UNSERVICIO_CODIGO`) VALUES
(165, '2021-12-18', 'Efectivo', 163, 2, NULL, 13),
(166, '2021-12-02', 'Tarjeta de credito', 164, 156, 17, NULL),
(169, '2021-12-10', 'Tarjeta de credito', 163, 156, NULL, 12);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`ID_CLIENTE`);

--
-- Indices de la tabla `cliente_venta`
--
ALTER TABLE `cliente_venta`
  ADD PRIMARY KEY (`Cliente_ID_CLIENTE`,`listaVentas_NUM_VENTA`),
  ADD KEY `FK_CLIENTE_VENTA_listaVentas_NUM_VENTA` (`listaVentas_NUM_VENTA`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`ID_EMPLEADO`),
  ADD KEY `FK_EMPLEADO_UNUSUARIO_ID` (`UNUSUARIO_ID`);

--
-- Indices de la tabla `empleado_venta`
--
ALTER TABLE `empleado_venta`
  ADD PRIMARY KEY (`Empleado_ID_EMPLEADO`,`listaVentas_NUM_VENTA`),
  ADD KEY `FK_EMPLEADO_VENTA_listaVentas_NUM_VENTA` (`listaVentas_NUM_VENTA`);

--
-- Indices de la tabla `paquete_turistico`
--
ALTER TABLE `paquete_turistico`
  ADD PRIMARY KEY (`CODIGO`);

--
-- Indices de la tabla `paquete_turistico_servicio`
--
ALTER TABLE `paquete_turistico_servicio`
  ADD PRIMARY KEY (`Paquete_turistico_CODIGO`,`listaServicios_CODIGO`),
  ADD KEY `PAQUETE_TURISTICO_SERVICIO_listaServicios_CODIGO` (`listaServicios_CODIGO`);

--
-- Indices de la tabla `paquete_turistico_venta`
--
ALTER TABLE `paquete_turistico_venta`
  ADD PRIMARY KEY (`Paquete_turistico_CODIGO`,`listaVentas_NUM_VENTA`),
  ADD KEY `FK_PAQUETE_TURISTICO_VENTA_listaVentas_NUM_VENTA` (`listaVentas_NUM_VENTA`);

--
-- Indices de la tabla `sequence`
--
ALTER TABLE `sequence`
  ADD PRIMARY KEY (`SEQ_NAME`);

--
-- Indices de la tabla `servicio`
--
ALTER TABLE `servicio`
  ADD PRIMARY KEY (`CODIGO`);

--
-- Indices de la tabla `servicio_paquete_turistico`
--
ALTER TABLE `servicio_paquete_turistico`
  ADD PRIMARY KEY (`Servicio_CODIGO`,`listaPaquetes_CODIGO`),
  ADD KEY `FK_SERVICIO_PAQUETE_TURISTICO_listaPaquetes_CODIGO` (`listaPaquetes_CODIGO`);

--
-- Indices de la tabla `servicio_venta`
--
ALTER TABLE `servicio_venta`
  ADD PRIMARY KEY (`Servicio_CODIGO`,`listaVentas_NUM_VENTA`),
  ADD KEY `FK_SERVICIO_VENTA_listaVentas_NUM_VENTA` (`listaVentas_NUM_VENTA`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `venta`
--
ALTER TABLE `venta`
  ADD PRIMARY KEY (`NUM_VENTA`),
  ADD KEY `FK_VENTA_UNSERVICIO_CODIGO` (`UNSERVICIO_CODIGO`),
  ADD KEY `FK_VENTA_UNEMPLEADO_ID_EMPLEADO` (`UNEMPLEADO_ID_EMPLEADO`),
  ADD KEY `FK_VENTA_UNPAQUETE_CODIGO` (`UNPAQUETE_CODIGO`),
  ADD KEY `FK_VENTA_UNCLIENTE_ID_CLIENTE` (`UNCLIENTE_ID_CLIENTE`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cliente_venta`
--
ALTER TABLE `cliente_venta`
  ADD CONSTRAINT `FK_CLIENTE_VENTA_Cliente_ID_CLIENTE` FOREIGN KEY (`Cliente_ID_CLIENTE`) REFERENCES `cliente` (`ID_CLIENTE`),
  ADD CONSTRAINT `FK_CLIENTE_VENTA_listaVentas_NUM_VENTA` FOREIGN KEY (`listaVentas_NUM_VENTA`) REFERENCES `venta` (`NUM_VENTA`);

--
-- Filtros para la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD CONSTRAINT `FK_EMPLEADO_UNUSUARIO_ID` FOREIGN KEY (`UNUSUARIO_ID`) REFERENCES `usuario` (`ID`);

--
-- Filtros para la tabla `empleado_venta`
--
ALTER TABLE `empleado_venta`
  ADD CONSTRAINT `FK_EMPLEADO_VENTA_Empleado_ID_EMPLEADO` FOREIGN KEY (`Empleado_ID_EMPLEADO`) REFERENCES `empleado` (`ID_EMPLEADO`),
  ADD CONSTRAINT `FK_EMPLEADO_VENTA_listaVentas_NUM_VENTA` FOREIGN KEY (`listaVentas_NUM_VENTA`) REFERENCES `venta` (`NUM_VENTA`);

--
-- Filtros para la tabla `paquete_turistico_servicio`
--
ALTER TABLE `paquete_turistico_servicio`
  ADD CONSTRAINT `PAQUETE_TURISTICO_SERVICIOPaquete_turistico_CODIGO` FOREIGN KEY (`Paquete_turistico_CODIGO`) REFERENCES `paquete_turistico` (`CODIGO`),
  ADD CONSTRAINT `PAQUETE_TURISTICO_SERVICIO_listaServicios_CODIGO` FOREIGN KEY (`listaServicios_CODIGO`) REFERENCES `servicio` (`CODIGO`);

--
-- Filtros para la tabla `paquete_turistico_venta`
--
ALTER TABLE `paquete_turistico_venta`
  ADD CONSTRAINT `FK_PAQUETE_TURISTICO_VENTA_listaVentas_NUM_VENTA` FOREIGN KEY (`listaVentas_NUM_VENTA`) REFERENCES `venta` (`NUM_VENTA`),
  ADD CONSTRAINT `PAQUETE_TURISTICO_VENTA_Paquete_turistico_CODIGO` FOREIGN KEY (`Paquete_turistico_CODIGO`) REFERENCES `paquete_turistico` (`CODIGO`);

--
-- Filtros para la tabla `servicio_paquete_turistico`
--
ALTER TABLE `servicio_paquete_turistico`
  ADD CONSTRAINT `FK_SERVICIO_PAQUETE_TURISTICO_Servicio_CODIGO` FOREIGN KEY (`Servicio_CODIGO`) REFERENCES `servicio` (`CODIGO`),
  ADD CONSTRAINT `FK_SERVICIO_PAQUETE_TURISTICO_listaPaquetes_CODIGO` FOREIGN KEY (`listaPaquetes_CODIGO`) REFERENCES `paquete_turistico` (`CODIGO`);

--
-- Filtros para la tabla `servicio_venta`
--
ALTER TABLE `servicio_venta`
  ADD CONSTRAINT `FK_SERVICIO_VENTA_Servicio_CODIGO` FOREIGN KEY (`Servicio_CODIGO`) REFERENCES `servicio` (`CODIGO`),
  ADD CONSTRAINT `FK_SERVICIO_VENTA_listaVentas_NUM_VENTA` FOREIGN KEY (`listaVentas_NUM_VENTA`) REFERENCES `venta` (`NUM_VENTA`);

--
-- Filtros para la tabla `venta`
--
ALTER TABLE `venta`
  ADD CONSTRAINT `FK_VENTA_UNCLIENTE_ID_CLIENTE` FOREIGN KEY (`UNCLIENTE_ID_CLIENTE`) REFERENCES `cliente` (`ID_CLIENTE`),
  ADD CONSTRAINT `FK_VENTA_UNEMPLEADO_ID_EMPLEADO` FOREIGN KEY (`UNEMPLEADO_ID_EMPLEADO`) REFERENCES `empleado` (`ID_EMPLEADO`),
  ADD CONSTRAINT `FK_VENTA_UNPAQUETE_CODIGO` FOREIGN KEY (`UNPAQUETE_CODIGO`) REFERENCES `paquete_turistico` (`CODIGO`),
  ADD CONSTRAINT `FK_VENTA_UNSERVICIO_CODIGO` FOREIGN KEY (`UNSERVICIO_CODIGO`) REFERENCES `servicio` (`CODIGO`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
